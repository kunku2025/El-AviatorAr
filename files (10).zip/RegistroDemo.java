import java.util.Scanner;

public class RegistroDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== REGISTRO DE USUARIO (DEMO) ===");
        System.out.print("Ingrese su nombre: ");
        String nombre = scanner.nextLine();

        System.out.print("Ingrese su usuario: ");
        String usuario = scanner.nextLine();

        System.out.print("Ingrese su correo: ");
        String correo = scanner.nextLine();

        System.out.print("Ingrese su contraseña: ");
        String contrasena = scanner.nextLine();

        System.out.print("Ingrese su edad: ");
        int edad = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer

        if (edad < 18) {
            System.out.println("Debes ser mayor de 18 años para registrarte.");
            return;
        }

        // Mostrar reglas generales (resumidas)
        System.out.println("\n--- Términos y Condiciones ---");
        System.out.println("Este juego es una DEMO, solo para mayores de 18 años. No hay premios reales ni apuestas de dinero. ");
        System.out.println("Al aceptar, renuncias a cualquier reclamo judicial contra los responsables del juego.");
        System.out.println("Dispones de 5 minutos para aceptar los términos y condiciones.\n");

        long inicio = System.currentTimeMillis();
        boolean acepto = false;

        System.out.print("¿Acepta los términos y condiciones? (si/no): ");
        while (true) {
            if (System.currentTimeMillis() - inicio > 5 * 60 * 1000) {
                System.out.println("Tiempo excedido. Debe aceptar dentro de los 5 minutos.");
                return;
            }
            String respuesta = scanner.nextLine().trim().toLowerCase();
            if (respuesta.equals("si")) {
                acepto = true;
                break;
            } else if (respuesta.equals("no")) {
                break;
            } else {
                System.out.print("Responda 'si' o 'no': ");
            }
        }

        if (!acepto) {
            System.out.println("Debe aceptar los términos y condiciones para registrarse.");
            return;
        }

        // Registro exitoso (solo demo)
        System.out.println("\nRegistro exitoso (DEMO). Bienvenido/a, " + nombre + "!");
        System.out.println("Recuerde: esta plataforma es solo una demostración, no hay premios de dinero ni apuestas reales.");

        scanner.close();
    }
}