# Reglas Generales – Juego “Aviador” (DEMO)

## 1. Ámbito Legal  
Estas reglas aplican a usuarios residentes en la República Argentina y al resto del mundo. El acceso y uso del juego “Aviador” están sujetos a la legislación vigente en el país de residencia del usuario y, en caso de conflicto, prevalecerán las normas jurídicas argentinas para la interpretación y aplicación de las presentes reglas. Los usuarios son responsables de cumplir con todas las leyes locales aplicables.

## 2. Restricción de Edad  
Solo pueden participar personas mayores de 18 años. Al registrarse, el usuario declara y garantiza que cumple con este requisito.

## 3. Carácter de Demostración  
**Este juego es una DEMO, destinado únicamente a fines demostrativos, educativos o de entretenimiento. No implica apuestas con dinero real ni premios económicos. Ningún rendimiento, resultado o premio obtenido en esta plataforma tiene validez fuera del entorno demostrativo.**

## 4. Protección de Datos  
La información provista por los usuarios será tratada conforme a la Ley de Protección de Datos Personales (Ley 25.326) de la República Argentina y, para usuarios fuera de Argentina, siguiendo principios internacionales de privacidad y protección de datos. No se compartirán datos personales con terceros sin consentimiento expreso, salvo obligación legal.

## 5. Limitación de Responsabilidad  
Los desarrolladores y administradores del juego “Aviador” no se responsabilizan por cualquier daño directo o indirecto derivado del uso del juego, ni por interrupciones, errores técnicos o pérdidas de información.

## 6. Aceptación de Condiciones y Renuncia a Reclamos Judiciales  
El uso de la plataforma implica la aceptación plena de estas reglas generales. Al aceptar estas condiciones, el usuario declara expresamente que renuncia a concurrir a la justicia o iniciar cualquier tipo de reclamo judicial contra los desarrolladores, administradores o responsables de la plataforma, en virtud del carácter demostrativo y no vinculante del juego. El usuario puede consultar los términos y condiciones completos en cualquier momento.

## 7. Tiempo para Aceptación  
El usuario dispone de un plazo máximo de 5 minutos para leer y aceptar estas reglas y condiciones. Si no acepta en ese tiempo, el registro o acceso será cancelado automáticamente y deberá reiniciar el proceso.

---

**Nota:**  
*Este producto es solo una demostración (“demo”) y no representa un juego real con premios monetarios ni participación en apuestas. Solo para mayores de 18 años, residentes en Argentina y en el resto del mundo.*